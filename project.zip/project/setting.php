<?php
Class Setting{ 
    function __construct(){ 
    $this->atur['namapt']="Toko Amma"; 
    $this->atur['alamat']="Jl. Alamat Disini \nBandung";//pastikan ada tanda \n untuk pemisah nama jalan dan nama Kota agar tampilan lebih baik 
    $this->atur['telpon']="082116586584"; 
    $this->atur['judul']="Invoice"; 
    $this->atur['kota']="Bandung"; 
   } 
   }
?>